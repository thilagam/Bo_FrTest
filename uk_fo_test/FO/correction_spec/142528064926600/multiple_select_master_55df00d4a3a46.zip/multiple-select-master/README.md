# Multiple Select

Multiple select is a jQuery plugin to select multiple elements with checkboxes :).

To get started checkout examples and documentation at http://wenzhixin.net.cn/p/multiple-select

## Contributors

[CONTRIBUTORS](https://github.com/wenzhixin/multiple-select/blob/master/CONTRIBUTORS.md)

## Changelog

[CHANGELOG](https://github.com/wenzhixin/multiple-select/blob/master/CHANGELOG.md)

## LICENSE

[The MIT License](https://github.com/wenzhixin/multiple-select/blob/master/LICENSE)